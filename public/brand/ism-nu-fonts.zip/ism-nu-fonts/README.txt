Fonts of the ISM group brand, from the group website.

Archivo Condensed ExtraBold: headlines (the site's Archivo at 62% width).
Archivo Regular and Bold: body text.
Doto Black: the dot-matrix face of the logo and big numbers.

Install them before using the PowerPoint templates. In Canva, upload them to a
Brand Kit (paid or education plans only) or use the "Canva fonts" templates.
Archivo and Doto have no Cyrillic: for Russian, use the "Canva fonts"
templates. Both families are under the SIL Open Font License, included here.
